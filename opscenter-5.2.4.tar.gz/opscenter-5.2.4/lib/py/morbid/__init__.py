__version__ = "0.8.7.4"
from morbid import StompFactory, StompProtocol, get_stomp_factory, main
import messagequeue
import mqsecurity
